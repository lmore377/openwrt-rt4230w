Login Web 
ADVANCED-Admin-Configuration

1.0.11
user 4230w
password admin

1.1.11-1.1.16(DHCP only)
user 4230w
password linuxbox

Cannot connect wireless!
TTL has 2.00MM