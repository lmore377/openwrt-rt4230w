Login Web 
ADVANCED-Admin-Configuration

1.0.11
user 4230w
password admin

1.1.11-1.1.16
user 4230w
password linuxbox

1.1.28
user technician
password linuxbox

If you get an unable to negotiate error, use this ssh command:
ssh -oKexAlgorithms=+diffie-hellman-group1-sha1 <username for your version>@192.168.1.1
